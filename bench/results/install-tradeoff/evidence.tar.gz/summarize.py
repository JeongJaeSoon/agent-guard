from pathlib import Path
import json,statistics,math
p=Path('/workspace/agent-guard-pipeline-evidence/install-tradeoff-20261104');rows=json.loads((p/'results.json').read_text());res={'build':{},'hooks_public':{},'hooks_control':{}}
for name in ['control','candidate']:
 x=[r for r in rows if r['label'].startswith('build-') and r['label'].endswith(name)]
 res['build'][name]={'wall_seconds':statistics.median(r['wall_seconds'] for r in x),'cpu_seconds':statistics.median(r['user_cpu_seconds']+r['system_cpu_seconds'] for r in x),'max_child_peak_rss_kib':statistics.median(r['max_child_peak_rss_kib'] for r in x),'sampled_peak_rss_sum_kib':statistics.median(r['sampled_peak_rss_sum_kib'] for r in x)}
for kind,prefix in [('public',''),('control','control-')]:
 for host in ['claude','codex']:
  d=json.loads((p/f'hook-{prefix}{host}.json').read_text()); c=d['cases'][0];h={'verified':c['verified'],'baseline':{},'candidate':{}}
  for arm in ['baseline','candidate']:
   r=c['resource_usage'][arm];h[arm]={'wall_seconds':c['seconds'][arm]['median'],'cpu_seconds':statistics.median(a+b for a,b in zip(r['user_cpu_seconds']['samples'],r['system_cpu_seconds']['samples'])),'max_child_peak_rss_kib':r['max_child_peak_rss_kib']['median']}
  if kind=='control':h['source_build_break_even']={k:math.ceil(max(0,res['build']['candidate'][k]-res['build']['control'][k])/(h['baseline'][k]-h['candidate'][k])) for k in ['wall_seconds','cpu_seconds']}
  res['hooks_'+kind][host]=h
res['limits']='Local 4CPU/16GiB, not CI2CPU/1GiB. Source-build break-even: one cold build then sequential measured off-cache many-leaf hooks using rebuilt control/candidate, same compiler. Not ordinary user installation or universal workload. Memory peaks cannot be amortized.'
(p/'matched-tradeoff-summary.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
