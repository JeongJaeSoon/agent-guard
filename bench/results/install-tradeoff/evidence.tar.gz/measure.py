#!/usr/bin/env python3
"""격리된 scanner 설치 부분 비용과 개발자 cold build 비용을 교대 측정한다."""
import gzip, hashlib, json, os, pathlib, statistics, subprocess, sys, tarfile, time
ROOT=pathlib.Path('/workspace/agent-guard-pipeline-evidence/install-tradeoff-20261104')
TOOLS=pathlib.Path('/workspace/agent-guard-tools')
DRIVER='/workspace/agent-guard-patch-prep/native/devtools/target/release/agent-guard-devtools'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,indent=2)+'\n')
if len(sys.argv)>1 and sys.argv[1]=='unpack':
 archive,expected,dest=sys.argv[2:]
 archive=pathlib.Path(archive); dest=pathlib.Path(dest)
 assert sha(archive)==expected
 with tarfile.open(archive) as t:
  m=t.getmembers(); assert len(m)==1 and m[0].name=='gitleaks' and m[0].isfile()
  dest.mkdir(); (dest/'gitleaks').write_bytes(t.extractfile(m[0]).read()); (dest/'gitleaks').chmod(0o755)
 sys.exit(0)
ROOT.mkdir(exist_ok=False)
write(ROOT/'conditions.json',{'scope':'scanner-only prebuilt verification/unpack (no network/host setup); developer source builds (not required for users)', 'cpu_max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'memory_max':pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip(),'sample_rss_note':'10ms process-group RSS sum duplicates shared pages and can miss peaks', 'build_cache':'new empty GOCACHE per sample; prepopulated dependency cache; no network; filesystem cache not dropped','go':'1.26.0','source':'83d9cd684c87d95d656c1458ef04895a7f1cbd8e','source_notes':'same documented test-only generator import fixes on both sources; candidate go-re21.13.0 + x/sys.48 vs control1.9.0'})
rows=[]
def run(label,command,cwd=None,env=None):
 d=ROOT/label; d.mkdir(); out=(d/'stdout').open('wb'); err=(d/'stderr').open('wb')
 start=time.monotonic(); p=subprocess.Popen([DRIVER,'resource-sample',str(d/'resource.json'),*command],cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
 peak=0; samples=[]
 while p.poll() is None:
  rss=0
  for proc in pathlib.Path('/proc').iterdir():
   if not proc.name.isdigit(): continue
   try:
    st=(proc/'stat').read_text().rsplit(')',1)[1].split()
    if int(st[2])==p.pid and int(proc.name)!=p.pid:
     rss+=int((proc/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')//1024
   except (OSError,ValueError,IndexError): pass
  peak=max(peak,rss); samples.append([time.monotonic()-start,rss]); time.sleep(.01)
 out.close();err.close()
 row={'label':label,'command':command,'exit':p.returncode,'sampled_peak_rss_sum_kib':peak}
 if (d/'resource.json').exists():row.update(json.loads((d/'resource.json').read_text()))
 write(d/'rss-samples.json',samples);write(d/'result.json',row);rows.append(row);write(ROOT/'results.json',rows)
 print(json.dumps(row),flush=True)
 if p.returncode: raise SystemExit('measurement failed; preserve evidence')
 return row
binaries={'public':TOOLS/'gitleaks','control':TOOLS/'scanners/control/gitleaks','candidate':TOOLS/'scanners/re2-113/gitleaks'}
packages={}
for name,binary in binaries.items():
 archive=ROOT/(name+'.tar.gz')
 with archive.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='',compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  info=tarfile.TarInfo('gitleaks');info.size=binary.stat().st_size;info.mode=0o755
  with binary.open('rb') as b:t.addfile(info,b)
 packages[name]={'binary_bytes':binary.stat().st_size,'binary_sha256':sha(binary),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive)}
write(ROOT/'packages.json',packages)
for trial in range(7):
 for name in (['public','candidate'] if trial%2==0 else ['candidate','public']):
  run(f'unpack-{trial}-{name}',[sys.executable,__file__,'unpack',str(ROOT/(name+'.tar.gz')),packages[name]['archive_sha256'],str(ROOT/f'extracted-{trial}-{name}')])
  assert sha(ROOT/f'extracted-{trial}-{name}'/'gitleaks')==packages[name]['binary_sha256']
for trial in range(3):
 for name in (['control','candidate'] if trial%2==0 else ['candidate','control']):
  d=ROOT/f'build-{trial}-{name}'; cache=ROOT/f'cache-{trial}-{name}';cache.mkdir()
  env=os.environ.copy();env.update(GOPATH=str(TOOLS/'gopath'),GOCACHE=str(cache),GOTOOLCHAIN='local',CGO_ENABLED='0',GOPROXY='off',GOSUMDB='off')
  source=TOOLS/('gitleaks-source' if name=='control' else 'gitleaks-re2-113')
  command=[str(TOOLS/'go-dist/go1.26.0/go/bin/go'),'build','-buildvcs=false','-trimpath','-tags','gore2regex','-ldflags','-s -w -X=github.com/zricethezav/gitleaks/v8/version.Version=8.30.1','-o',str(d/'gitleaks')]
  run(f'build-{trial}-{name}',command,cwd=source,env=env)
  write(d/'binary.json',{'sha256':sha(d/'gitleaks'),'size':(d/'gitleaks').stat().st_size})
summary={}
for kind,names in [('unpack',['public','candidate']),('build',['control','candidate'])]:
 summary[kind]={}
 for name in names:
  values=[r for r in rows if r['label'].startswith(kind+'-') and r['label'].endswith('-'+name)]
  summary[kind][name]={k:statistics.median(r[k] for r in values) for k in ['wall_seconds','user_cpu_seconds','system_cpu_seconds','max_child_peak_rss_kib','sampled_peak_rss_sum_kib']}
write(ROOT/'summary.json',summary)
