#!/bin/sh
set -eu
archive=$1
expected=$2
destination=$3
printf '%s  %s\n' "$expected" "$archive" | shasum -a 256 -c -
mkdir "$destination"
tar -xzf "$archive" -C "$destination"
