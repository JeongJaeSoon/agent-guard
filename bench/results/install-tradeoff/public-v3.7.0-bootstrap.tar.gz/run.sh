#!/bin/sh
set -eu
trial=$1
for compiler in cargo rustc go cc gcc; do
 if command -v "$compiler"; then echo 'unexpected compiler' >&2; exit 1; fi
done
test "$HOME" = /root
jq --version > "/evidence/$trial-tools.log"
gitleaks version >> "/evidence/$trial-tools.log"
/usr/bin/time -f '{"wall_seconds":%e,"user_cpu_seconds":%U,"system_cpu_seconds":%S,"max_child_peak_rss_kib":%M,"exit":%x}' -o "/evidence/$trial-resource.json" env AGENT_GUARD_VERSION=3.7.0 sh /release/bootstrap.sh > "/evidence/$trial-install.log" 2>&1
/root/.local/bin/agent-guard version > "/evidence/$trial-version.log"
(cd /root/.agent-guard/libexec && shasum -a 256 -c ./*.sha256) > "/evidence/$trial-native-checksums.log"
/root/.local/bin/agent-guard smoke-test > "/evidence/$trial-smoke.log" 2>&1
