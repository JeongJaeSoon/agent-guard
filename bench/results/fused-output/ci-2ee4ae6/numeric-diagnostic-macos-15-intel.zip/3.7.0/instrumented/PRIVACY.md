# Privacy and Data Handling

Last updated: 2026-09-11

Agent Guard is local by default. The project does not operate an Agent Guard
service, account system, telemetry collector, crash reporter, or analytics
endpoint. Default hook processing does not transmit inspected data. It does not
retain it after the hook or command finishes. Since v3.4.0 it maintains a
default-on, metadata-only local support log; the log records no inspected
content.

## What the plugin processes

When enabled, Agent Guard registers hooks for `SessionStart`, `UserPromptSubmit`,
`PreToolUse`, `PostToolUse`, and `Stop`.

| Surface | Data inspected | Purpose | Persistent storage |
|---|---|---|---|
| `UserPromptSubmit` | The full text of the prompt the user submits | Block (or, opt-in, warn about) secret-like values and opt-in PII classes before the prompt reaches the model or the transcript | None |
| `PreToolUse` | Matched tool names and inputs, including paths, proposed content, shell commands, URLs/search queries, and MCP arguments | Block deny-listed reads, credential-dumping commands, secret-like input, and opt-in PII classes before execution | None |
| `PostToolUse` | Matched tool outputs; after mutation tools, changed and untracked files in the current Git work tree | Mask secret-like output and opt-in PII; detect secrets written to the work tree | None |
| `Stop` | Changed and untracked files in the current Git work tree | Final working-tree secret scan | None |
| `SessionStart` | Dependency availability and Agent Guard shell-integration version marker | Report degraded setup or version drift | None |
| CLI and shell wrappers | Only stdin, paths, or command output explicitly passed by the user | On-demand scan or masking | None |
| Local support log | Random local `run_id`, version, command/event category, host, start/finish time, exit status, and coarse outcome | Diagnose a local installation without retaining inspected data | Local metadata only; no content, paths, environment variables, host session IDs, or arbitrary tool names |

Temporary scan reports and provider responses are created under a single
per-invocation directory inside the operating system temporary directory and
removed by a cleanup trap when the operation exits — including on the
interrupting signals a host actually sends: SIGTERM when it kills a hook at its
timeout, and SIGINT on Ctrl-C. Only an un-trappable SIGKILL can bypass this,
leaving those temporary files for the operating system's temporary-directory
reaper to remove. Agent Guard does not write inspected tool content to its own
log or database. The host application may independently retain tool inputs and
outputs under its own privacy policy.

## Local support log

The metadata log is available in v3.4.0 and later; it is not present in v3.3.0.
Agent Guard writes metadata-only JSONL records under
`$XDG_STATE_HOME/agent-guard` or, when that variable is unset,
`~/.local/state/agent-guard`. It creates a start record and completes it with
one of `pass`, `blocked`, `masked`, `warned`, `degraded`, `error`, or `interrupted`.
The `run_id` is a random local invocation-correlation value, not a host session
identifier.
`pass` only means the invocation returned without a block; it is not evidence
that every scanner or host route was clean.

The default retention target is 1,000 invocations and seven days. Cleanup runs
once at invocation start, examines at most 2,000 top-level entries, and only
removes generated event names. Concurrent runs or externally populated storage
can exceed that target; cleanup remains bounded. No cleanup runs
on the signal/exit path. Logging is best-effort and never changes a guard decision.
The same directory holds `gitleaks-probe`, which records the resolved gitleaks
path, its file identity and version after a successful readiness check, so later
invocations within ten minutes can skip rerunning `gitleaks version`. Every
invocation still runs its own scan.
Set `AGENT_GUARD_LOG_MODE=off` to opt out; the readiness check then runs in
every invocation. `agent-guard logs status` reports
local log state and `agent-guard logs export` writes the safe metadata JSONL to
standard output. Neither command exports inspected content, file paths,
environment values, host session identifiers, or arbitrary tool names.

## Network behavior

Normal lifecycle hooks and the built-in `regex` PII provider make no outbound
network calls. Web and MCP tool inputs are inspected locally before the host
decides whether to execute those tools; Agent Guard does not forward them.

The following explicit actions use the network:

- `agent-guard checksum` fetches the published gitleaks checksum list from
  GitHub Releases. It sends no project or tool content.
- Approval-gated `agent-guard setup --install` downloads a versioned gitleaks
  archive from GitHub Releases and requires its SHA-256. It sends no project or
  tool content.
- The standalone `bootstrap.sh` install path downloads Agent Guard's release
  archive and checksum from this project's GitHub Releases page.
  `agent-guard update` first downloads that `bootstrap.sh` from the latest
  release.
- `agent-guard doctor`, `agent-guard plugin status`, and `agent-guard plugin
  update` can send one `HEAD` request to this project's GitHub
  `releases/latest` URL to learn the newest version. It sends no project or
  tool content. Set `AGENT_GUARD_RELEASE_CHECK=off` to skip it.
- `agent-guard plugin install` and `agent-guard plugin update` run the Claude
  Code or Codex plugin manager, which fetches this project's marketplace from
  GitHub.
- If the user selects the experimental `AGENT_GUARD_PII_PROVIDER=http` adapter
  or the `AGENT_GUARD_PII_PROVIDER=pleno` adapter, `agent-guard pii-filter`
  sends the complete text provided on stdin to the exact URL in
  `AGENT_GUARD_PII_REDACT_URL`. In
  `AGENT_GUARD_PII_HOOK_MODE=block`, supported tool-input text is sent to that
  same endpoint to determine whether it contains PII, and so is the complete
  text of every prompt the user submits. A prompt is not a tool input: it
  carries whatever the user typed or pasted, including material unrelated to
  the project. The endpoint's operator, not Agent Guard, controls its
  collection, retention, and deletion practices.

PII hook handling defaults to `off`; the default provider is the local `regex`
adapter. `mask` mode performs input Tier-2 detection and output masking locally,
even if an endpoint-backed adapter is configured. Agent Guard never chooses or
enables a remote PII endpoint on the user's behalf.

## User controls

- Disable or uninstall the plugin to stop all Agent Guard lifecycle hooks.
- Keep `AGENT_GUARD_PII_HOOK_MODE=off` to disable PII processing in hooks.
- Use `AGENT_GUARD_PII_PROVIDER=regex` to keep `pii-filter` local.
- Set `AGENT_GUARD_OUTPUT_REDACT=off` to disable secret-like output masking.
  This reduces protection and is not recommended.
- Decline the guided setup installation prompt to prevent software downloads.

For vulnerabilities, use the private channel in [SECURITY.md](SECURITY.md).
For questions and support, see [SUPPORT.md](SUPPORT.md).
