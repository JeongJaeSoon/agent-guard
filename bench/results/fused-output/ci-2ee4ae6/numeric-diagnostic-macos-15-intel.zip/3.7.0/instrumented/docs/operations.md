# Operations

## Managed Claude Code rollout

Merge the Agent Guard keys into existing organization JSON, rather than replacing
unrelated settings. Use `/Library/Application Support/ClaudeCode/managed-settings.json`
on macOS and `/etc/claude-code/managed-settings.json` on Linux/WSL.

Start from [`deployment/claude-managed-settings.example.json`](../deployment/claude-managed-settings.example.json).
It pins the marketplace source to a release tag, force-enables the plugin,
restricts marketplace sources, and disables automatic refreshes. Pin a reviewed
release tag; marketplace `ref` accepts a branch or tag, not a commit SHA. The
release workflow updates the canonical JSON example linked above. Merge that
file from the release you reviewed, then add the rollout's environment settings.
Change the tag only through an intentional, reviewed rollout.

The example intentionally has no `env` block. The product defaults are
`AGENT_GUARD_INFRA_FAILURE_MODE=open` and `AGENT_GUARD_PII_HOOK_MODE=off`. The
metadata-only local support log is available and default-on in v3.4.0 and later.
For a rollout that prioritizes secret protection, use
`AGENT_GUARD_INFRA_FAILURE_MODE=closed`.
PII is opt-in; do not force an
endpoint-backed provider without a separate privacy review. Set
`AGENT_GUARD_LOG_MODE=off` only in a release that contains the log and where
the metadata-only local support log is not permitted.

After policy delivery, each developer runs the host setup skill, approves any
dependency installation, restarts the host/session when asked, and completes
the live probes in [Verification](verification.md). Repeat this acceptance path
after every version or policy update.

In Claude Code, the user-facing sequence is:

```text
/agent-guard:setup-agent-guard
/agent-guard:setup-shell
/agent-guard:verify
```

The first skill resolves the installed plugin-local binary, so it remains
correct when a different standalone version is present on `PATH`. The last
command is a working-tree scan; it does not prove hook dispatch. Complete both
live probes after it.

`setup-agent-guard` diagnoses the plugin-local binary and its dependencies; it
does not install a second Agent Guard CLI on `PATH`. `setup-shell` writes the
plugin's stable `current/bin` directory into the selected bash or zsh rc. After
restarting that shell, the same plugin-local executable is available as the
bare `agent-guard` command without Homebrew or the standalone bootstrap.

For Codex, hooks are reviewed by their exact current definition. A changed hook
must be reviewed/trusted again before it runs. See official [Codex Hooks](https://learn.chatgpt.com/docs/hooks).

## Troubleshooting

| Symptom | Meaning and next action |
| --- | --- |
| `DEGRADED` | A dependency or policy could not be verified. Run `doctor`, then setup; it is not a clean scan. |
| `setup ok (dependencies only)` | Local dependencies are available. Run the live route probes. |
| Probe prints its raw marker | The tested route did not dispatch the expected hook. Check trust, restart, and retain Git/CI backstops. |
| Post-tool probe reports `[REDACTED]` with a `run_id` | A PostToolUse rewrite produced that replacement. Resolve the same `run_id` in `agent-guard logs export` before accepting the report; an id with no record is a failed probe. |
| A benign command is blocked as a protected path | The shell matcher saw path-shaped text. The search pattern of a plain `grep`, `egrep` or `fgrep` command (unless `GREP_OPTIONS` is set in the hook's environment) or `rg --no-config` command, and the not-yet-existing `-out`/`-keyout` path of `openssl req`, `genrsa`, `genpkey` or `ecparam`, are not counted. Anything else, including those commands behind a wrapper, an expansion, an unlisted option, a multi-line script, or after a command or redirection that may change what a later command name runs (`hash`, `read`, or anything that may write a file, such as `git`, `touch` or `>`), still is. BSD grep reads `GREP_OPTIONS`, which can turn the pattern into a file; a value exported only inside the agent's shell profile is not visible to the hook. Use a clearly non-path-shaped expression after reviewing the command. |
| `a git commit or push may run ... that could not be resolved safely` on a command that runs a CLI through a variable | The commit/push gate reads `$NAME` as that command only when the same command line assigns NAME once, at top level, to plain words that are not git or a shell. It stays unknown, and the closed policy blocks, when the line also runs git or a shell, calls a function that runs `"$@"`, sets a `trap`, or uses `eval`, `source` or `read` as a command. A script file given to a shell through a variable (`S=./run.sh; for n in 1 2; do bash "$S" $n; done`) is read as that file when the line assigns S once, at top level, to one plain word, even though the line runs a shell; the gate does not read the script's contents, as with `bash ./run.sh`. Write the CLI name out instead of the variable, or split such a script into separate commands. |
| The same message on a here-document or a `git -C $DIR` read | A body behind a quoted delimiter (`<<'EOF'`, `<<"EOF"`, `<<\EOF`) is text when `cat`, `tee`, `python`, `gh` (other than `gh alias set --shell`) or `git commit` reads it and nothing else on that line can: no pipe, subshell, process substitution, background job, a shell or a path that runs a file the line names elsewhere (in any letter case, or through a glob). Behind an unquoted delimiter the body is text too, but its `$(...)`, backticks and `$((...))` substitutions run as code. An unquoted `$NAME` git argument is the word NAME was set to when the line assigns it once, at top level, to one plain word (`~/x` and `$HOME/x` expand to HOME); a space, a glob, a brace next to `$NAME`, or code for a shell or a git alias keeps it unknown. Quote the delimiter, or write the path out. |
| The message ends with a reason in parentheses | It names the part that stayed unknown: a command name only known at run time, a `cd` after a command that may create or relink paths (named, such as git `clone`), a `cd` to a directory only known at run time, or an unquoted variable in a git option. Run the commit or push as its own Bash call, as `git -C <absolute path>` with literal arguments. |
| `a git commit or push runs in a directory that does not exist or is not a git repository when the hook runs` | The command creates the repository it commits in (`git init`, `git clone`), so there is nothing to scan before it runs. Create the repository in one Bash call, then commit or push in the next. |
| `awk failed while reading the command variables` | The resolver itself failed, so the command name was not decided either way. Run `doctor` and check which `awk` is first on `PATH`. |
| Post-write scan is unavailable | Treat it as infrastructure failure under the configured policy; do not claim the file was clean. |
| `exceeded the scan input limit of N bytes` | One pending change (often a regenerated lockfile) is larger than the scan budget. Split it, or set `AGENT_GUARD_SCAN_INPUT_MAX_BYTES` higher; a larger budget scans more, it never skips input. |
| `git diff failed` followed by `git: <line>` | git itself failed before the scan ran. The second line is git's first stderr line, truncated; act on it (bad revision, corrupt index) rather than on the scanner. |

## Claude shell integration

The plugin install and `setup-agent-guard` alone do not put `agent-guard` on
`PATH`. In Claude Code, run `/agent-guard:setup-shell`; it resolves the
plugin-local executable and
requests approval before changing the shell rc. If the host cannot approve that
write, run the exact plugin-local command shown by the skill in a terminal. Do
not substitute an unrelated standalone binary on `PATH`.

The following bare commands apply to a standalone install or to a bash/zsh
terminal restarted after `setup-shell`:

```sh
agent-guard setup-shell
agent-guard setup-shell --no-command-wrapping
```

Restart the shell and every Claude Code session launched from it. The default
installs command wrapping; `--no-command-wrapping` is the persistent opt-out and
`AGENT_GUARD_COMMAND_WRAPPING=off` is a runtime opt-out. The integration is
text-only and does not make interactive shell escapes a complete security
boundary.

### fish

`shell-init` emits POSIX shell code, so fish cannot evaluate it. A standalone
install can use `agent-guard exec -- <command>` directly. For a plugin-only
installation, use the stable plugin-cache resolver path printed by
`/agent-guard:setup-shell`; its normal shape is
`$HOME/.claude/plugins/cache/agent-guard/agent-guard/current/bin/agent-guard`.

```fish
function agx
    if type -q agent-guard
        command agent-guard exec -- $argv
        return $status
    end

    set -l _ag "$HOME/.claude/plugins/cache/agent-guard/agent-guard/current/bin/agent-guard"
    if not test -x "$_ag"
        printf 'agent-guard: plugin binary not found; rerun /agent-guard:setup-shell and use the fish executable path it prints\n' >&2
        return 127
    end
    command "$_ag" exec -- $argv
end
funcsave agx
```

The `current/bin/agent-guard` path is refreshed by plugin execution. If the
plugin cache is elsewhere, use the executable path printed by setup instead.
