import pathlib,subprocess,json,hashlib
root=pathlib.Path(__file__).resolve().parent
repo='https://github.com/JeongJaeSoon/agent-guard.git'
driver='/workspace/agent-guard-fused/native/devtools/target/release/agent-guard-devtools'
rows=[]
for name,opts,sha in [('v370-shallow',['--depth','1','--single-branch','--no-tags','--branch','v3.7.0'],'e709445fb6fce9ade8cbbd2d6bcf2940e48da178'),('candidate-shallow',['--depth','1','--single-branch','--no-tags','--branch','release/v3.8.0'],'f49740f27e0de96fe0c683e72776066a0afa240c'),('current-all-branches',['--branch','release/v3.8.0'],'f49740f27e0de96fe0c683e72776066a0afa240c')]:
 out=root/name;out.mkdir();dest=out/'checkout';argv=['git','clone',*opts,repo,str(dest)]
 (out/'command.json').write_text(json.dumps(argv))
 with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
  r=subprocess.run([driver,'resource-sample',str(out/'resource.json'),*argv],stdout=stdout,stderr=stderr)
 assert r.returncode==0,(name,r.returncode)
 actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=dest,text=True).strip();assert actual==sha,(name,actual)
 packs=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((dest/'.git/objects/pack').glob('*.pack'))]
 subprocess.run(['git','count-objects','-v'],cwd=dest,stdout=(out/'objects.txt').open('w'),check=True)
 row={'mode':name,'head':actual,'pack_bytes':sum(p['bytes'] for p in packs),'packs':packs,'checkout_files_bytes':sum(p.stat().st_size for p in dest.rglob('*') if p.is_file() and '.git' not in p.relative_to(dest).parts),'resource':json.loads((out/'resource.json').read_text())}
 rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
(root/'scope.json').write_text(json.dumps({'scope':'one live network clone per mode; includes checkout; Git pack bytes exclude HTTP/TLS overhead; current all-branch clone is not historical v3.7.0 transfer; actual Claude/Codex internal clone options not established; not a performance adoption comparison','host_cpu_max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text(),'host_memory_max':pathlib.Path('/sys/fs/cgroup/memory.max').read_text()},indent=2))
