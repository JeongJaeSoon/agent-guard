#!/bin/sh
set -eu
redact_plaintext_framed() {
  text=$1
  secret_file=$2
  printf '%s' "$text" | LC_ALL=C awk -v secret_file="$secret_file" '
    function add_mapping(literal, replacement, contextual, key) {
      key = contextual ":" length(literal) ":" literal \
        ":" length(replacement) ":" replacement
      if (length(literal) > 0 && !seen[key]) {
        seen[key] = 1
        lit[++count] = literal
        rep[count] = replacement
        ctx[count] = contextual
      }
    }
    function consume_record(value, tag, payload) {
      tag = substr(value, 1, 1)
      payload = substr(value, 2)
      if (tag == "S") add_mapping(payload, "[REDACTED]", 0)
      else if (tag == "L") pending_literal = payload
      else if (tag == "R") {
        add_mapping(pending_literal, payload, 1)
        pending_literal = ""
      }
    }
    function feed_framed(line, i, ch) {
      record_ended_at_boundary = 0
      for (i = 1; i <= length(line); i++) {
        ch = substr(line, i, 1)
        if (escaped) {
          record = record ch
          escaped = 0
          record_ended_at_boundary = 0
        } else if (ch == escape) {
          escaped = 1
          record_ended_at_boundary = 0
        } else if (ch == boundary) {
          consume_record(record)
          record = ""
          record_ended_at_boundary = 1
        } else {
          record = record ch
          record_ended_at_boundary = 0
        }
      }
      if (!record_ended_at_boundary) record = record "\n"
    }
    BEGIN {
      boundary = sprintf("%c", 30)
      escape = sprintf("%c", 31)
      while ((status = getline line < secret_file) > 0) feed_framed(line)
      close(secret_file)
      if (status < 0) read_error = 1
      for (i = 2; i <= count; i++) {
        value = lit[i]
        replacement = rep[i]
        contextual = ctx[i]
        j = i - 1
        while (j >= 1 &&
               (ctx[j] < contextual ||
                (ctx[j] == contextual &&
                 length(lit[j]) < length(value)))) {
          lit[j + 1] = lit[j]
          rep[j + 1] = rep[j]
          ctx[j + 1] = ctx[j]
          j--
        }
        lit[j + 1] = value
        rep[j + 1] = replacement
        ctx[j + 1] = contextual
      }
    }
    { buf = (NR == 1 ? $0 : buf ORS $0) }
    END {
      if (read_error) exit 2
      if (count > 256 || count * (length(buf) + 1) > 8000000) exit 3
      for (i = 1; i <= count; i++) {
        value = lit[i]
        replacement = rep[i]
        contextual = ctx[i]
        out = ""
        at = index(buf, value)
        while (at > 0) {
          after = substr(buf, at + length(value), 1)
          if (!contextual || after == "" || after == ORS ||
              after ~ /[ \t,;]/)
            out = out substr(buf, 1, at - 1) replacement
          else
            out = out substr(buf, 1, at - 1) value
          buf = substr(buf, at + length(value))
          at = index(buf, value)
        }
        buf = out buf
      }
      printf "%s", buf
    }
  '
}

text=$(cat "$1")
redact_plaintext_framed "$text" "$2"
