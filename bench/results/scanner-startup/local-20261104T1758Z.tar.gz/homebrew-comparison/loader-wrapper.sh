#!/bin/sh
# Unmodified public bottle, executed by the available system loader.
# Isolated audit-off experiment only; this is not an installation method.
exec /lib64/ld-linux-x86-64.so.2 /workspace/agent-guard-tools/scanners/homebrew-public/gitleaks/8.30.1/bin/gitleaks "$@"
