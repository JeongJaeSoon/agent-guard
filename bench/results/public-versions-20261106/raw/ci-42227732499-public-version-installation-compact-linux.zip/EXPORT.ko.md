# 설치 원시 자료의 소형 내보내기

이 자료는 이미 완료한 설치 실험의 기존 artifact를 읽어서 만든다. 설치나 성능 측정을 다시 실행하지 않는다. 원본 ZIP의 ID·크기·SHA-256을 고정 검증한다.

`installation-work` 안에서 공개 릴리스/고정 scanner와 SHA-256이 일치하는 배포 파일의 반복 복사를 제외했다. 여기에는 실행 파일·배포 압축 파일뿐 아니라 GIF/PNG 등 이미 압축된 공개 자료도 포함한다. 그 밖의 결과 JSON, 로그, 전송 기록, 반환 상태, 사용자 설정 sentinel, `.bashrc`, 보존 파일 및 중간 생성물은 유지한다. 모든 원본 파일의 경로·크기·SHA-256·ZIP mode와 제외 사유는 `work-file-manifest.csv`에 남는다.

원본 전체 artifact의 URL과 만료일은 `source-artifact.json` 및 `export-summary.json`을 참고한다. GitHub 원본의 보존 기간은 30일이며 영구 보존이라고 주장하지 않는다. 이 소형 원시 자료는 보고서 저장소에 함께 보존한다.
