# >>> agent-guard shell-init >>>
# Managed by 'agent-guard setup-shell' — remove this block to disable.
eval "$(
_agbin='/results/installation-work/cached/standalone-fresh-cached-r8-v3.6.15/home/.agent-guard/bin/agent-guard'
_agbase=''
__agentguard_bin=$_agbin
__agentguard_plugin_base=$_agbase
eval '__agentguard_policy_file_usable() {
  [ -f "$1" ] && [ ! -L "$1" ] && [ -r "$1" ] && [ -s "$1" ] \
    && awk '\''$0 !~ /^[[:space:]]*(#|$)/ { found = 1; exit } END { exit !found }'\'' "$1"
}
__agentguard_cache_bin_usable() {
  __ag_candidate=$1
  __ag_expected=${2:-}
  __ag_root=${__ag_candidate%/bin/agent-guard}
  [ -d "$__ag_root" ] && [ ! -L "$__ag_root" ] \
    && [ -d "$__ag_root/bin" ] && [ ! -L "$__ag_root/bin" ] \
    && [ -d "$__ag_root/config" ] && [ ! -L "$__ag_root/config" ] \
    && [ -f "$__ag_candidate" ] && [ ! -L "$__ag_candidate" ] && [ -x "$__ag_candidate" ] \
    && __agentguard_policy_file_usable "$__ag_root/config/gitleaks.toml" \
    && __agentguard_policy_file_usable "$__ag_root/config/deny-read-paths.txt" \
    && __agentguard_policy_file_usable "$__ag_root/config/deny-bash-patterns.txt" \
    || return 1
  __ag_embedded=
  while IFS= read -r __ag_line; do
    case "$__ag_line" in
      VERSION=*) __ag_embedded=${__ag_line#VERSION=}; break ;;
    esac
  done <"$__ag_candidate"
  [ -n "$__ag_embedded" ] \
    && { [ -z "$__ag_expected" ] || [ "$__ag_embedded" = "$__ag_expected" ]; }
}
__agentguard_latest_plugin_bin() {
  [ -n "${__agentguard_plugin_base:-}" ] || return 1
  __ag_latest=$(
    for __ag_candidate in "$__agentguard_plugin_base"/[0-9]*.[0-9]*.[0-9]*/bin/agent-guard; do
      [ -x "$__ag_candidate" ] || continue
      __ag_root=${__ag_candidate%/bin/agent-guard}
      [ -d "$__ag_root" ] && [ ! -L "$__ag_root" ] || continue
      __ag_version=${__ag_candidate%/bin/agent-guard}
      __ag_version=${__ag_version##*/}
      __agentguard_cache_bin_usable "$__ag_candidate" "$__ag_version" || continue
      printf '\''%s\t%s\n'\'' "$__ag_version" "$__ag_candidate"
    done \
      | awk -F '\''\t'\'' '\''$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+$/'\'' \
      | sort -t. -k1,1n -k2,2n -k3,3n \
      | tail -n 1 \
      | cut -f 2-
  )
  [ -n "$__ag_latest" ] && [ -x "$__ag_latest" ] || return 1
  printf '\''%s'\'' "$__ag_latest"
}
__agentguard_semver() {
  __ag_version=$1
  __ag_major=${__ag_version%%.*}
  __ag_rest=${__ag_version#*.}
  [ "$__ag_rest" != "$__ag_version" ] || return 1
  __ag_minor=${__ag_rest%%.*}
  __ag_patch=${__ag_rest#*.}
  [ "$__ag_patch" != "$__ag_rest" ] || return 1
  case "$__ag_major" in '\'''\''|*[!0-9]*) return 1 ;; esac
  case "$__ag_minor" in '\'''\''|*[!0-9]*) return 1 ;; esac
  case "$__ag_patch" in '\'''\''|*[!0-9]*) return 1 ;; esac
  return 0
}
__agentguard_physical_path() (
  __ag_physical=$1
  case "$__ag_physical" in
    /*) ;;
    *)
      __ag_pwd=$(pwd -P 2>/dev/null) || return 1
      __ag_physical=$__ag_pwd/$__ag_physical
      ;;
  esac
  __ag_hops=0
  while [ -L "$__ag_physical" ]; do
    __ag_hops=$((__ag_hops + 1))
    [ "$__ag_hops" -le 40 ] || return 1
    __ag_target=$(readlink -- "$__ag_physical" 2>/dev/null) || return 1
    case "$__ag_target" in
      /*) __ag_physical=$__ag_target ;;
      *) __ag_physical=${__ag_physical%/*}/$__ag_target ;;
    esac
  done
  __ag_name=${__ag_physical##*/}
  __ag_parent=${__ag_physical%/*}
  [ "$__ag_parent" != "$__ag_physical" ] || __ag_parent=.
  __ag_parent=$(CDPATH= cd -- "$__ag_parent" 2>/dev/null && pwd -P) || return 1
  printf '\''%s/%s'\'' "$__ag_parent" "$__ag_name"
)
__agentguard_path_bin() {
  __ag_path=$(command -v agent-guard 2>/dev/null) || __ag_path=
  if [ -n "$__ag_path" ]; then
    # setup-shell adds current/bin to PATH. Do not re-admit an invalid cache
    # through a relative entry or an external symlink alias after rejecting its
    # payload above. Canonicalize only in plugin mode; standalone PATH fallback
    # retains support for command wrappers that are not payload-shaped paths.
    if [ -n "${__agentguard_plugin_base:-}" ]; then
      __ag_path=$(__agentguard_physical_path "$__ag_path") || return 1
      __ag_base=$(CDPATH= cd -- "$__agentguard_plugin_base" 2>/dev/null && pwd -P) \
        || __ag_base=
      if [ -n "$__ag_base" ]; then
        case "$__ag_path" in "$__ag_base"|"$__ag_base"/*) return 1 ;; esac
      fi
    fi
    printf '\''%s'\'' "$__ag_path"; return 0
  fi
  return 1
}
__agentguard_exe() {
  if [ -n "${AGENT_GUARD_BIN:-}" ] && [ -x "$AGENT_GUARD_BIN" ]; then
    printf '\''%s'\'' "$AGENT_GUARD_BIN"; return 0
  fi
  __ag_current_target=
  if [ -n "${__agentguard_plugin_base:-}" ] \
     && [ -L "$__agentguard_plugin_base/current" ]; then
    __ag_current_target=$(readlink "$__agentguard_plugin_base/current" 2>/dev/null) \
      || __ag_current_target=
    __agentguard_semver "$__ag_current_target" || __ag_current_target=
  fi
  if [ -n "${__agentguard_bin:-}" ] && [ -x "$__agentguard_bin" ] \
     && [ -n "${__agentguard_plugin_base:-}" ] \
     && [ -n "$__ag_current_target" ] \
     && [ -d "$__agentguard_plugin_base/$__ag_current_target" ] \
     && [ ! -L "$__agentguard_plugin_base/$__ag_current_target" ] \
     && __agentguard_cache_bin_usable \
          "$__agentguard_plugin_base/$__ag_current_target/bin/agent-guard" \
          "$__ag_current_target"; then
    printf '\''%s'\'' "$__agentguard_bin"; return 0
  fi
  __ag_latest=$(__agentguard_latest_plugin_bin) || __ag_latest=
  if [ -n "$__ag_latest" ]; then
    printf '\''%s'\'' "$__ag_latest"; return 0
  fi
  if [ -z "${__agentguard_plugin_base:-}" ] \
     && [ -n "${__agentguard_bin:-}" ] && [ -x "$__agentguard_bin" ]; then
    printf '\''%s'\'' "$__agentguard_bin"; return 0
  fi
  __agentguard_path_bin
}'
_agi=
_agresolved=$(__agentguard_exe) || _agresolved=
if [ -n "$_agresolved" ]; then
  _agi=$("$_agresolved" shell-init 2>/dev/null) || _agi=
fi
if [ -z "$_agi" ]; then
  _agfallback=$(__agentguard_path_bin) || _agfallback=
  if [ -n "$_agfallback" ] && [ "$_agfallback" != "$_agresolved" ]; then
    _agi=$("$_agfallback" shell-init 2>/dev/null) || _agi=
  fi
fi
[ -n "$_agi" ] && printf '%s\n' "$_agi"
)"
# <<< agent-guard shell-init <<<
