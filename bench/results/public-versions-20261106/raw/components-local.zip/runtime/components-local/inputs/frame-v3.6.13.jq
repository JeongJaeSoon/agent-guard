
    .. | strings
    | (split("\u001f") | join("\u001f\u001f"))
    | (split("\u001e") | join("\u001f\u001e"))
    | . + "\u001e\n"