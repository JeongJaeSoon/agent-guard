#!/bin/sh
set -eu
version=$1
trial=$2
case "$version" in 3.7.0) release=/release-old ;; 3.7.1) release=/release-new ;; *) exit 2 ;; esac
for compiler in cargo rustc go cc gcc; do
 if command -v "$compiler"; then echo 'unexpected compiler' >&2; exit 1; fi
done
test "$HOME" = /root
label="$trial-$version"
/usr/bin/time -f '{"wall_seconds":%e,"user_cpu_seconds":%U,"system_cpu_seconds":%S,"max_child_peak_rss_kib":%M,"exit":%x}' -o "/evidence/$label-fresh-resource.json" env AGENT_GUARD_VERSION="$version" sh "$release/bootstrap.sh" > "/evidence/$label-fresh.log" 2>&1
/root/.local/bin/agent-guard version > "/evidence/$label-version.log"
cmp /root/.agent-guard/bin/agent-guard "$release/payload/bin/agent-guard"
(cd /root/.agent-guard/libexec && shasum -a 256 -c ./*.sha256) > "/evidence/$label-native-checksums.log"
/root/.local/bin/agent-guard smoke-test > "/evidence/$label-smoke.log" 2>&1
if [ "$version" = 3.7.0 ] && [ "${3:-fresh}" = update ]; then
 printf 'preserve published installation note\n' > /root/.agent-guard/local-note
 /usr/bin/time -f '{"wall_seconds":%e,"user_cpu_seconds":%U,"system_cpu_seconds":%S,"max_child_peak_rss_kib":%M,"exit":%x}' -o "/evidence/$label-update-resource.json" env AGENT_GUARD_VERSION=3.7.1 /root/.local/bin/agent-guard update > "/evidence/$label-update.log" 2>&1
 /root/.local/bin/agent-guard version | grep -F 'agent-guard 3.7.1'
 cmp /root/.agent-guard/bin/agent-guard /release-new/payload/bin/agent-guard
 grep -F 'preserve published installation note' /root/.agent-guard/local-note
 /root/.local/bin/agent-guard smoke-test > "/evidence/$label-updated-smoke.log" 2>&1
fi
