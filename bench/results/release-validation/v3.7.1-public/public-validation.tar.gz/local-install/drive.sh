#!/bin/bash
set -euo pipefail
comparison_dir=/workspace/agent-guard-pipeline-evidence/public-install-comparison
old_release=/workspace/agent-guard-pipeline-evidence/public-validator-preflight
new_release=/workspace/agent-guard-pipeline-evidence/public-v3.7.1
[[ -f "$old_release/verification.json" && -f "$new_release/verification.json" ]]
if compgen -G "$comparison_dir/*-resource.json" >/dev/null; then
 echo 'Refusing to overwrite existing installation samples' >&2
 exit 2
fi
docker_local() {
 env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH docker --host=unix:///var/run/docker.sock "$@"
}
[[ $(docker_local image inspect agent-guard-public-install:20261104 --format '{{.Id}}') = sha256:b4bb415311de1abaa4dc7f4026b5ad28e642b10af78d8481ac32a9e219420706 ]]
run_install() {
 docker_local run --rm \
  --mount "type=bind,src=$comparison_dir,dst=/evidence" \
  --mount "type=bind,src=$old_release,dst=/release-old,readonly" \
  --mount "type=bind,src=$new_release,dst=/release-new,readonly" \
  --mount type=bind,src=/workspace/agent-guard-tools/gitleaks,dst=/usr/local/bin/gitleaks,readonly \
  --mount type=bind,src=/etc/ssl/certs/ca-certificates.crt,dst=/run/system-ca.pem,readonly \
  -e SSL_CERT_FILE=/run/system-ca.pem -e CURL_CA_BUNDLE=/run/system-ca.pem \
  agent-guard-public-install:20261104 sh /evidence/run.sh "$@"
}
for trial in 1 2 3; do
 if [[ $trial = 2 ]]; then order=(3.7.1 3.7.0); else order=(3.7.0 3.7.1); fi
 for version in "${order[@]}"; do run_install "$version" "$trial"; done
done
for trial in 1 2 3; do run_install 3.7.0 "update-$trial" update; done
