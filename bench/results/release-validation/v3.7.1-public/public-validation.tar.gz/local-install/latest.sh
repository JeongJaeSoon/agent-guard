#!/bin/sh
set -eu
unset AGENT_GUARD_VERSION
for compiler in cargo rustc go cc gcc; do if command -v "$compiler"; then exit 1; fi; done
curl -fsSL https://github.com/JeongJaeSoon/agent-guard/releases/latest/download/bootstrap.sh -o /tmp/public-bootstrap.sh
cmp /tmp/public-bootstrap.sh /release-new/bootstrap.sh
sh /tmp/public-bootstrap.sh > /evidence/latest-install.log 2>&1
/root/.local/bin/agent-guard version | tee /evidence/latest-version.log
grep -F 'agent-guard 3.7.1' /evidence/latest-version.log
/root/.local/bin/agent-guard smoke-test > /evidence/latest-smoke.log 2>&1
